﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wahlgren.CapstoneDesign02
{
    class Converter
    {
        //Atributes
        private String outputString="";

        public Converter() 
        {
            //Constructor
        }
        
        public bool obtainNumberToChange(String inputString)
        {
            try
            {
                Convert.ToDouble(inputString);
            }
            catch
            {
                outputString = "invalid input";
                    return false;
            }

            convertInputToWords(inputString);           // this happended when i try to fix the problem. when trying to implement inputChar
            return true;
        }

        public String getOutputString()
        {
            return outputString;
        }

        public void convertInputToWords(String inputString)
        {
            if (inputString.Length == 3)
            {
                decodeHundredsAndOnes(inputString[0]);
                outputString += "hundred ";
                // if(inputString.Length) // greater than 1
                decodeTens(inputString);            // Had problems when typing for example 12 it said twenty because of the decodeteens and the inputchar
                if (inputString[1] != '1')
                    decodeHundredsAndOnes(inputString[2]);
            }
            else if (inputString.Length == 2)
            {
                decodeTens(inputString);
                if (inputString[0] != '1')
                    decodeHundredsAndOnes(inputString[1]);
            }
            else
            {
                decodeHundredsAndOnes(inputString[0]);
            }
        }

        private void decodeHundredsAndOnes(char inputChar)
        {
            switch (inputChar)
            {
                case '1':
                    outputString += "one ";
                    break;
                case '2':
                    outputString += "two ";
                    break;
                case '3':
                    outputString += "three ";
                    break;
                case '4':
                    outputString += "four ";
                    break;
                case '5':
                    outputString += "five ";
                    break;
                case '6':
                    outputString += "six ";
                    break;
                case '7':
                    outputString += "seven ";
                    break;
                case '8':
                    outputString += "eight ";
                    break;
                case '9':
                    outputString += "nine ";
                    break;
                default:
                    break;
            }
        }

        private void decodeTens(String inputString)
        {
            int n = 1;
            if(inputString.Length == 2)
            {
                n = 0;
            }
            switch (inputString[n])
            {
                case '1':
                    {
                        switch (inputString[n + 1])
                        {
                            case '0':
                                outputString += "ten";
                                break;
                            case '1':
                                outputString += "eleven";
                                break;
                            case '2':
                                outputString += "twelve";
                                break;
                            case '3':
                                outputString += "thirteen";
                                break;
                            case '4':
                                outputString += "fourteen";
                                break;
                            case '5':
                                outputString += "fitfhteen";
                                break;
                            case '6':
                                outputString += "sixteen";
                                break;
                            case '7':
                                outputString += "seventeen";
                                break;
                            case '8':
                                outputString += "eithteen";
                                break;
                            case '9':
                                outputString += "nineteen";
                                break;
                            default:
                                break;
                        }
                        
                        break;  
                    }
                case '2':
                    outputString += "twenty ";
                    break;
                case '3':
                    outputString += "thirty ";
                    break;
                case '4':
                    outputString += "fourty ";
                    break;
                case '5':
                    outputString += "fifty ";
                    break;
                case '6':
                    outputString += "sixty ";
                    break;
                case '7':
                    outputString += "seventy ";
                    break;
                case '8':
                    outputString += "eighty ";
                    break;
                case '9':
                    outputString += "ninety ";
                    break;
                default:
                    break;
            }
        }
    }
}
