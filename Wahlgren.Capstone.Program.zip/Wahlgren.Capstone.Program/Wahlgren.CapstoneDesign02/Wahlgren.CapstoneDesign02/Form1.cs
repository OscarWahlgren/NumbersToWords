﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wahlgren.CapstoneDesign02
{
    public partial class frmConverter : Form
    {
        public frmConverter()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAnswer_Click(object sender, EventArgs e)
        {
            //ThousandsMillionsCents findNumber = new ThousandsMillionsCents();
            //having problems calling the ThousandsMillionsCents class
            CreateBillionsMillionsThousandsHundredsCentsStrings convert = new CreateBillionsMillionsThousandsHundredsCentsStrings(tbxInput.Text);
            String[] convertedInput = convert.getInputBrokenIntoPieces();

            if(convertedInput[0] != null)
            {
                Converter makeWords = new Converter();
                makeWords.obtainNumberToChange(convertedInput[0]);
                lblAnswer.Text = makeWords.getOutputString() + "billions ";
            }

            if (convertedInput[1] != null)
            {
                Converter makeWords = new Converter();
                makeWords.obtainNumberToChange(convertedInput[1]);
                lblAnswer.Text += makeWords.getOutputString() + "millions ";
            }

            if (convertedInput[2] != null)
            {
                Converter makeWords = new Converter();
                makeWords.obtainNumberToChange(convertedInput[2]);
                lblAnswer.Text += makeWords.getOutputString() + "thousands ";
            }

            if (convertedInput[3] != null)
            {
                Converter makeWords = new Converter();
                makeWords.obtainNumberToChange(convertedInput[3]);
                lblAnswer.Text += makeWords.getOutputString() + "dollars ";
            }
            if (convertedInput[4] != null)
            {
                Converter makeWords = new Converter();
                makeWords.obtainNumberToChange(convertedInput[4]);
                lblAnswer.Text += makeWords.getOutputString() + " cents";
            }
           
        }

        private void tbxInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblAnswer_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            frmConverter newform = new frmConverter();
            newform.Show();
            this.Dispose(false);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
