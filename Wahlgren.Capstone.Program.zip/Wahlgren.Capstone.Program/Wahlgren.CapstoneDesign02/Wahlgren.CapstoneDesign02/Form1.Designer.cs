﻿
namespace Wahlgren.CapstoneDesign02
{
    partial class frmConverter
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAnswer = new System.Windows.Forms.Label();
            this.tbxInput = new System.Windows.Forms.TextBox();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.lblDescription = new System.Windows.Forms.Label();
            this.grpCurrency = new System.Windows.Forms.GroupBox();
            this.optPounds = new System.Windows.Forms.RadioButton();
            this.optFranks = new System.Windows.Forms.RadioButton();
            this.optEuros = new System.Windows.Forms.RadioButton();
            this.optDollars = new System.Windows.Forms.RadioButton();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.grpCurrency.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAnswer
            // 
            this.lblAnswer.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAnswer.Location = new System.Drawing.Point(15, 267);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(492, 67);
            this.lblAnswer.TabIndex = 0;
            this.lblAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAnswer.Click += new System.EventHandler(this.lblAnswer_Click);
            // 
            // tbxInput
            // 
            this.tbxInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxInput.Location = new System.Drawing.Point(200, 114);
            this.tbxInput.Name = "tbxInput";
            this.tbxInput.Size = new System.Drawing.Size(125, 27);
            this.tbxInput.TabIndex = 1;
            this.tbxInput.TextChanged += new System.EventHandler(this.tbxInput_TextChanged);
            // 
            // btnAnswer
            // 
            this.btnAnswer.Location = new System.Drawing.Point(200, 337);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(125, 29);
            this.btnAnswer.TabIndex = 2;
            this.btnAnswer.Text = "Convert";
            this.btnAnswer.UseVisualStyleBackColor = true;
            this.btnAnswer.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(3, 60);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(528, 20);
            this.lblDescription.TabIndex = 3;
            this.lblDescription.Text = "Put the amount you want to convert in the field below and select your currency";
            this.lblDescription.Click += new System.EventHandler(this.label1_Click);
            // 
            // grpCurrency
            // 
            this.grpCurrency.Controls.Add(this.optPounds);
            this.grpCurrency.Controls.Add(this.optFranks);
            this.grpCurrency.Controls.Add(this.optEuros);
            this.grpCurrency.Controls.Add(this.optDollars);
            this.grpCurrency.Location = new System.Drawing.Point(15, 157);
            this.grpCurrency.Name = "grpCurrency";
            this.grpCurrency.Size = new System.Drawing.Size(492, 77);
            this.grpCurrency.TabIndex = 4;
            this.grpCurrency.TabStop = false;
            this.grpCurrency.Text = "Currency";
            // 
            // optPounds
            // 
            this.optPounds.AutoSize = true;
            this.optPounds.Location = new System.Drawing.Point(381, 26);
            this.optPounds.Name = "optPounds";
            this.optPounds.Size = new System.Drawing.Size(77, 24);
            this.optPounds.TabIndex = 3;
            this.optPounds.TabStop = true;
            this.optPounds.Text = "Pounds";
            this.optPounds.UseVisualStyleBackColor = true;
            // 
            // optFranks
            // 
            this.optFranks.AutoSize = true;
            this.optFranks.Location = new System.Drawing.Point(274, 26);
            this.optFranks.Name = "optFranks";
            this.optFranks.Size = new System.Drawing.Size(71, 24);
            this.optFranks.TabIndex = 2;
            this.optFranks.TabStop = true;
            this.optFranks.Text = "Franks";
            this.optFranks.UseVisualStyleBackColor = true;
            // 
            // optEuros
            // 
            this.optEuros.AutoSize = true;
            this.optEuros.Location = new System.Drawing.Point(158, 26);
            this.optEuros.Name = "optEuros";
            this.optEuros.Size = new System.Drawing.Size(66, 24);
            this.optEuros.TabIndex = 1;
            this.optEuros.TabStop = true;
            this.optEuros.Text = "Euros";
            this.optEuros.UseVisualStyleBackColor = true;
            // 
            // optDollars
            // 
            this.optDollars.AutoSize = true;
            this.optDollars.Location = new System.Drawing.Point(37, 26);
            this.optDollars.Name = "optDollars";
            this.optDollars.Size = new System.Drawing.Size(77, 24);
            this.optDollars.TabIndex = 0;
            this.optDollars.TabStop = true;
            this.optDollars.Text = "Dollars";
            this.optDollars.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(52, 372);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(94, 29);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(379, 372);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(94, 29);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear Form";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 459);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpCurrency);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.btnAnswer);
            this.Controls.Add(this.tbxInput);
            this.Controls.Add(this.lblAnswer);
            this.Name = "frmConverter";
            this.Text = "Converter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpCurrency.ResumeLayout(false);
            this.grpCurrency.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.TextBox tbxInput;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.GroupBox grpCurrency;
        private System.Windows.Forms.RadioButton optPounds;
        private System.Windows.Forms.RadioButton optFranks;
        private System.Windows.Forms.RadioButton optEuros;
        private System.Windows.Forms.RadioButton optDollars;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
    }
}

