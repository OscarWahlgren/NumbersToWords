﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wahlgren.CapstoneDesign02
{
    //credit to Doc for code
    // I understand the code, might need a litle explantion on the cent methods. 
    //I palyed around with it a bit but i can't figure out how to connect it with the code in the convert class
    class ThousandsMillionsCents
    {
        private String[] brakeInputStringIntoPieces;
        //brakeInputStringIntoPieces[0] = millions
        //brakeInputStringIntoPieces[1] = thousends
        //brakeInputStringIntoPieces[2] = hundreds
        //brakeInputStringIntoPieces[3] = cents

        public ThousandsMillionsCents(String inputString)
        {
            String analyzeString = inputString;
            brakeInputStringIntoPieces = new string[4];

            if (analyzeString.Contains("."))
            {
                analyzeString = findCents(inputString);
            }

            if(analyzeString.Length > 6)
            {
                analyzeString = findMillions(analyzeString);
            }

            if(analyzeString.Length > 3)
            {
                analyzeString = findThousands(analyzeString);
            }

            if(analyzeString.Length > 0)
            {
                analyzeString = findHundreds(analyzeString);
            }
        }

        public String[] getBrokenInputIntoPieces()
        {
            return brakeInputStringIntoPieces;
        }

        private String findHundreds(String analyzeString)
        {
            brakeInputStringIntoPieces[2] = analyzeString;
            return "";
        }

        private String findThousands(String analyzeString)
        {
            if(analyzeString.Length < 6)
            {
                if(analyzeString.Length == 5)
                {
                    brakeInputStringIntoPieces[1] = analyzeString.Substring(0, 2);
                    return analyzeString.Substring(2);
                }
                else
                {
                    brakeInputStringIntoPieces[1] = analyzeString.Substring(0, 1);
                    return analyzeString.Substring(1);
                }
            }
            else
            {
                brakeInputStringIntoPieces[1] = analyzeString.Substring(0, 3);
                return analyzeString.Substring(3);
            }
        }

        private String  findMillions(String analyzeString)
        {
            if (analyzeString.Length < 9)
            {
                if(analyzeString.Length == 8)
                {
                    brakeInputStringIntoPieces[0] = analyzeString.Substring(0, 2);
                    return analyzeString.Substring(2);
                }
                else
                {
                    brakeInputStringIntoPieces[0] = analyzeString.Substring(0, 1);
                    return analyzeString.Substring(1);
                }
            }
            else
            {
                brakeInputStringIntoPieces[0] = analyzeString.Substring(0, 3);
                return analyzeString.Substring(3);
            }
        }

        private String findCents(String analyzeString)
        {
            int decimalPoint = analyzeString.IndexOf(".");

            while (analyzeString.Substring(decimalPoint).Length != 3)
            {
                analyzeString = analyzeString + "0";
            }
            
            brakeInputStringIntoPieces[3] = analyzeString.Substring(decimalPoint + 1);

            return analyzeString.Substring(0, decimalPoint);
        }
    }
}
